import React, { useRef, useEffect, useState } from 'react';
import mapboxgl from 'mapbox-gl';
// import MapboxDirections from "@mapbox/mapbox-gl-directions";
import MapboxDirections from  "@mapbox/mapbox-gl-directions/dist/mapbox-gl-directions";
import './map.css';




//mapboxgl.accessToken ='pk.ert345fgdgfdgfdgfdgs';
mapboxgl.accessToken = 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4M29iazA2Z2gycXA4N2pmbDZmangifQ.-g_vE53SD2WrJ6tFX7QHmA';

const Map = (prop) => {

  const mapContainerRef = useRef(null);

  const [lng, setLng] = useState(68.3719065);
  const [lat, setLat] = useState(25.3942879);
  const [zoom, setZoom] = useState(15);
  navigator.geolocation.getCurrentPosition(function(position) {
      
    setLng(position.coords.longitude);
    setLat(position.coords.latitude);
// console.log("Latitude is :", lat);
//       console.log("Longitude is :", lng);
    });
   
//   const [tmp, setTmp] = useState(false);

  // Initialize map when component mounts
  useEffect(() => {
    
   
 
    //const MapboxDirections = require('../test/direction');    
    const map = new mapboxgl.Map({
      
      container: mapContainerRef.current,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [lng,lat],
      zoom: zoom
    });
    map.addControl(new mapboxgl.FullscreenControl());
    // Add navigation control (the +/- zoom buttons)
    map.addControl(new mapboxgl.NavigationControl(), 'top-right');
if(true){
    map.on('move', () => {
      setLng(map.getCenter().lng.toFixed(4));
      setLat(map.getCenter().lat.toFixed(4));
      setZoom(map.getZoom().toFixed(9));
    });
  }

   if(prop._move=='true'){
    map.addControl(
        new MapboxDirections({
            accessToken: mapboxgl.accessToken
        }),
        'top-left'
    );
      }

if(prop.getPosition=='true')
    map.addControl(
        new mapboxgl.GeolocateControl({
            positionOptions: {
                enableHighAccuracy: true
            },
            trackUserLocation: true
        })
    );

    // map.addControl(new mapboxgl.NavigationControl());
    if(prop._fixedMarker=='true'){//prop._marker=='true'
    var marker = new mapboxgl.Marker()
    
        .setLngLat([lng, lat])
        .addTo(map);}
    ////////////////////////////////////////////////////////
    //var lngLata = getLngLat();
    if(prop._marker=='true'){
      var marker1 = new mapboxgl.Marker({
        draggable: true
        })
        .setLngLat([prop._longi, prop._lati])
        .addTo(map);
         
        function onDragEnd() {
        var lngLat = marker1.getLngLat();
        // coordinates.style.display = 'block';
        // coordinates.innerHTML =
        // 'Longitude: ' + lngLat.lng + '<br />Latitude: ' + lngLat.lat;
        prop.parentCallback(lngLat.lng,lngLat.lat);
        //alert(lngLat.lng+' '+lngLat.lat)
        }
         
        marker1.on('dragend', onDragEnd);
    }
    
    ///////////////////////////////////////////////////////////
    return () => map.remove();
    // Clean up on unmount
    
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // this.handleClick=()=>{
  //     alert('click')
  // }

  
  return (
    <div>
        
      
      <div className='sidebarStyle'>
        {/* <div>
          Longitude: {lng} | Latitude: {lat} | Zoom: {zoom}
        </div> */}
        
        
      </div>
      <div className='map-container' ref={mapContainerRef} style={{'height':'650px'}} />
      
      <pre id="coordinates" class="coordinates"></pre>
      
      
      
    </div>
    
  );
};

export default Map;