import React  from 'react';
import Clock from 'react-live-clock';
import a from './timeZone.json'

class MyComponent extends React.Component {
    render() {
        
        return(
<div>
{a.map((t,i)=>{
                return(
                    <div>
                    <div style={{'border':'1px solid black'}}>
                    <h2>
                        {t.value}
                    </h2>
                    <br/>
                    <h2>
                        {t.text}
                    </h2>
                    <br/>
                    <h2>
                        abbr:{t.abbr}
                    </h2>
                    <br/>
                    <h2>
                    offset:{t.offset}
                    </h2>
                    <br/>

                    
                    {t.utc.map((_utc,i)=>{
                        return(
                            <div>
                        <div style={{'border':'2px solid red'}}>
                            <h2>
                                {_utc}: <Clock format={'HH:mm:ss'} ticking={true} timezone={_utc} />
                            </h2>

                            </div>
                            <br/>
                            </div>

                        )

                    }
                    
                    )}
                   </div>
                   <br/>
                    </div>
                )
            })}
    <h1>
        <div>
          
        </div>
   
    </h1>

        {/* <Clock format={'HH:mm:ss'} ticking={true} timezone={'US/Pacific'} />
        <Clock format={'HH:mm:ss'} ticking={true} timezone={'US/Pacific'} /> */}
</div>
        )
        
    }
}
export default MyComponent