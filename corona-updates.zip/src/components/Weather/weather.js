import ReactWeather, { useOpenWeather } from 'react-open-weather';

const Appi = () => {
    
    var latitude=25.3942879,longitude=68.3719065,location;
    if (window.navigator && window.navigator.geolocation) {
        location = window.navigator.geolocation
    }
    if (location){
        location.getCurrentPosition(function (position) {
            latitude = position.coords.latitude;
            longitude= position.coords.longitude;
            console.log(latitude);
            console.log(longitude);
            // you should set state when you have the values.
        }.bind(this)); // you need to bind this so you can use setState
    }
  const { data, isLoading, errorMessage } = useOpenWeather({
    key: '67b2955ab7ee1be59f3a9bace944b9aa',
    lat: latitude,
    lon: longitude,
    lang: 'en',
    unit: 'metric', // values are (metric, standard, imperial)
  });
  return (
    <ReactWeather
      isLoading={isLoading}
      errorMessage={errorMessage}
      data={data}
      lang="en"
      locationLabel="Hyderabad"
      unitsLabels={{ temperature: 'C', windSpeed: 'Km/h' }}
      showForecast
    />
  );
};
export default Appi