import React from 'react';

import { Cards, CountryPicker, Chart } from './components';
import { fetchData } from './api/';
import styles from './App.module.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import image from './images/image.png';
import ReactWeather from 'react-open-weather';
 //import 'https://cdnjs.cloudflare.com/ajax/libs/weather-icons/2.0.9/css/weather-icons.min.css';
 import Appi from './components/Weather/weather'
import Map from './components/Map/Map'
import twitterClient from './components/Twitter/Twitter';
import MyComponent from './components/timeZone/TimeZone'

class App extends React.Component {
  state = {
    data: {},
    country: '',
    lati:25.3942879,
    longi:68.3719065
  }

  async componentDidMount() {
    const data = await fetchData();

    this.setState({ data });
    var latitude=25.3942879,longitude=68.3719065,location;
    if (window.navigator && window.navigator.geolocation) {
        location = window.navigator.geolocation
    }
    if (location){
        location.getCurrentPosition(function (position) {
            latitude = position.coords.latitude;
            longitude= position.coords.longitude;
            this.setState({
              lati:latitude,longi:longitude
            })
            console.log(latitude);
            console.log(longitude);
            // you should set state when you have the values.
        }.bind(this)); // you need to bind this so you can use setState
    }
  }

  handleCountryChange = async (country) => {
    const data = await fetchData(country);

    this.setState({ data, country: country });
  }
  

  render() {
    // const { dataa, isLoading, errorMessage } = useOpenWeather({
    //   key: 'YOUR-API-KEY',
    //   lat: '48.137154',
    //   lon: '11.576124',
    //   lang: 'en',
    //   unit: 'metric', // values are (metric, standard, imperial)
    // });
    const { data, country } = this.state;

    return (
      <div className="row">
        <div className="col-12 d-flex justify-content-center">
<img className={styles.image} src={image} alt="COVID-19" />
      </div>

       <div className="col-8">
       <div className={styles.container}>
        
        
        <Cards data={data} />
        <CountryPicker handleCountryChange={this.handleCountryChange} />
        <Chart data={data} country={country} /> 
      </div>

       </div> 

      <Appi className="col-4 "/>
      <div className="col-10 " style={{'height':'700px' ,'width':'700px','marginTop':'170px'}}>
      <Map 
					getPosition="true" 
					_marker="true" 
					_move="true"
					_lati={this.state.lati} 
					_longi={this.state.longi} 
          />
<twitterClient/>

<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="500" style={{'border':'none','overflow':'hidden'}} scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
<MyComponent/>
      </div>
      
     

      </div> 
      
    );
  }
}

export default App;